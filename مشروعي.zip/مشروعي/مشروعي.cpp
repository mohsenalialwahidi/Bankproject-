﻿#include <iostream>
#include "clsMainScreen.h";

int main()
{

    system("pause>0");
    return 0;
}